<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="bg-white">
      <div class="mx-auto max-w-2xl py-5 px-4 sm:py-5 sm:px-6 lg:max-w-7xl lg:px-8">
        <div class="p-5 text-lg dark:text-dark font-serif font-bold">
          <p class="text-4xl text-center">Our Cakes!</p>
	        <hr class="mx-auto w-48 h-1 rounded border-0" style="background-color: antiquewhite">
        </div>
        <div class="grid grid-cols-4 gap-4">
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="rounded-lg shadow-lg bg-white max-w-xs hover:scale-110 transition duration-300 ease-in-out">
            <a href="/category/<?php echo e($cat['id']); ?>" data-mdb-ripple="true" data-mdb-ripple-color="light">
            <img class="rounded-t-lg object-contain max-h-xs" src="/images/<?php echo e($cat['category_img']); ?>">

            <div class="p-6">
            <h5 class="text-xl font-bold mb-2" style="color: #AB9163"><?php echo e($cat['category_name']); ?></h5>
            <p class="text-gray-700 mb-4">
              <?php echo e($cat['category_desc']); ?>

            </p>
            </div>
          </a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
  <br>
  <br>
  <br>
  <br>
  <?php echo $__env->make("layouts/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body><?php /**PATH C:\Users\Steven\Desktop\Laravel Project\dailyslice-master\resources\views/category.blade.php ENDPATH**/ ?>