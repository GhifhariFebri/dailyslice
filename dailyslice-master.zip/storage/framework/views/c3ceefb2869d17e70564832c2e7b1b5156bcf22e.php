<?php echo $__env->make('layouts/navbaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="overflow-x-auto relative shadow-md sm:rounded-lg">
<h1 class="text-center p-5">Category Table</h1>
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        <thead>
            <tr class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <th scope="row" class="py-4 px-6 font-xl whitespace-nowrap dark:text-white">
                </th>
                <td class="py-4 px-6">
                    No
                </td>
                <td class="py-4 px-6">
                    Nama Category
                </td>
                <td class="py-4 px-6">
                    Image Category
                </td>
                <td class="py-4 px-6">
                    Desc Category
                </td>
                <td class="py-4 px-6">
                    Action
                </td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <th scope="row" class="py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                </th>

                <td class="py-4 px-6">
                    <?php echo e($loop->iteration); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($cat['category_name']); ?>

                </td>
                <td class="py-4 px-6">
                    <img src="/img/" alt=""><?php echo e($cat['category_img']); ?>

                </td>
                <td class="py-4 px-6">
                    <?php echo e($cat['category_desc']); ?>

                </td>
                <td><form action="<?php echo e(route('category.destroy', $cat->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\dailyslice-master\resources\views/admin.blade.php ENDPATH**/ ?>