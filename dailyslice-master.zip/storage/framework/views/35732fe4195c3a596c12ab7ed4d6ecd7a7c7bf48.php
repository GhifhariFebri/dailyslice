<?php echo $__env->make("layouts/navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="p-5 text-lg dark:text-dark font-serif font-bold items-center text-center">
        <p class="text-4xl text-center">About Us</p>
	    <hr class="mx-auto w-48 h-1 rounded border-0" style="background-color: antiquewhite">

        <div class="flex justify-center">
            <div>
                <img class="rounded max-w-md my-6" src="images/aboutus.jpg" alt="">
                <p class="max-w-md text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere, et necessitatibus fuga vel impedit pariatur porro amet ducimus, dignissimos tempora assumenda voluptatem veritatis incidunt reprehenderit quis, tenetur magni temporibus vero.</p>
            </div>
        </div>

    </div>

<?php echo $__env->make("layouts/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Steven\Desktop\Laravel Project\dailyslice-master\resources\views/aboutus.blade.php ENDPATH**/ ?>